# fighting-game
simple fighting game in javascript
