# Connect-the-Dots
**[Play the game!](https://deepsheth.github.io/connect-the-dots-game/ "Dots Demo")**


Responsive Web App using Fabric.js
